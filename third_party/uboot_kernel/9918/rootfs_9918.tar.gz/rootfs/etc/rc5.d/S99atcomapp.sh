#! /bin/sh
###################### mount partition
if [ ! -d "/usr/local/data/tmp" ];then
    mkdir /usr/local/data/tmp
fi
mount tmpfs /usr/local/data/tmp -t tmpfs -o size=8m


###################### if notstartapp env
notstartflag=`fw_printenv notstartapp`
if [ "$notstartflag" = 'notstartapp=1' ]; then
	exit 0
fi


##################### update kernel 
if [ -f "/usr/local/data/upgrade/app.tar.gz" ]; then
	UPDATE_APP_FLAG=1
else
	UPDATE_APP_FLAG=0
fi

if [ -f "/usr/local/data/upgrade/rootfs_list.tar.gz" ]; then
	UPDATE_ROOTFS_FLAG=1
else
	UPDATE_ROOTFS_FLAG=0
fi

if [ 1 -eq $UPDATE_APP_FLAG ] || [ 1 -eq $UPDATE_ROOTFS_FLAG ]; then
	echo "show update window"
	insmod /usr/local/atcom_version.ko
	insmod /usr/local/atcom_lcd.ko
	/usr/local/data/show_lcd_upgrade
fi

if [ 1 -eq $UPDATE_APP_FLAG ];then
	mv /usr/local/data/upgrade/app.tar.gz /usr/local/data/tmp/
	tar zxvf /usr/local/data/tmp/app.tar.gz -C /usr/local/
	rm -f /usr/local/data/tmp/app.tar.gz
	echo "update app"
fi

if [ 1 -eq $UPDATE_ROOTFS_FLAG ];then
	mv /usr/local/data/upgrade/rootfs_list.tar.gz /usr/local/data/tmp/
	tar zxvf /usr/local/data/tmp/rootfs_list.tar.gz -C /
	rm -f /usr/local/data/tmp/rootfs_list.tar.gz
	echo "update rootfs"
fi

if [ 1 -eq $UPDATE_APP_FLAG ] || [ 1 -eq $UPDATE_ROOTFS_FLAG ]; then
	sync; sync; sync; sleep 10
	shutdown -r now
fi

##################### start app
. /usr/local/app/initscript
