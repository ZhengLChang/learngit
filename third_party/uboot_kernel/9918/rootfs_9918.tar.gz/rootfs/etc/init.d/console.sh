#!/bin/sh

console=`cat /proc/cmdline | sed 's/.*console=\([^ ]*\).*/\1/g'`
ln -s /dev/$console /dev/ttyS
