bccmd -t bcsp -d /dev/ttyS0 -b 115200 psload -r /etc/bluetooth/platform_8810.psr
hciattach -s 115200 ttyS0 bcsp 115200 noflow
hciconfig hci0 noauth
hciconfig hci0 up
hciconfig hci0 noauth
