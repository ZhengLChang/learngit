#!/bin/sh
###################### mount data
ubiattach /dev/ubi_ctrl -m 5
devno=`cat /proc/devices | grep 'ubi1' | cut -d ' ' -f 1`
ubivol=`ubinfo -a | grep $devno:1`
if [ -z "$ubivol" ]; then
	ubidetach /dev/ubi_ctrl -m 5
	ubiformat /dev/mtd5 -y
	ubiattach /dev/ubi_ctrl -m 5
	ubimkvol /dev/ubi1 -m -N data
fi
mount -t ubifs ubi1_0 /usr/local/data/


#################### mount app
ubiattach /dev/ubi_ctrl -m 4
devno_app=`cat /proc/devices | grep 'ubi2' | cut -d ' ' -f 1`
ubivol_app=`ubinfo -a | grep $devno_app:1`
if [ -z "$ubivol_app" ]; then
	ubidetach /dev/ubi_ctrl -m 4
	ubiformat /dev/mtd4 -y
	ubiattach /dev/ubi_ctrl -m 4
	ubimkvol /dev/ubi2 -m -N app
fi
mount -t ubifs ubi2_0 /usr/local/app/


###################### if notstartapp env
notstartflag=`fw_printenv notstartapp`
if [ "$notstartflag" = 'notstartapp=1' ]; then
    exit 0
fi

###################### app script
. /usr/local/app/initscript
